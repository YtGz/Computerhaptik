% p v f
load b0_1.txt;
[n,p] = size(b0_1);
t = 1:n;
t = t*0.0005;
b0_1(:,3) = b0_1(:,3)*10;

figure
plot(t,b0_1(:,3)),
xlabel('Time [s]'), ylabel('Force [J/cm]')
title('2a Coloumb Friction b=0.1'),
legend('Force [J/cm]');

for i = 1:numel(b0_1(:,2))
   if(b0_1(i:2)>100);
       b0_1(i:2) = 0;
   end
   if(b0_1(i:2)<-100)
       b0_1(i:2) = 0;
   end
end

yyaxis right
plot(t,b0_1(:,2)),
ylabel('Velocity [mm/s]')