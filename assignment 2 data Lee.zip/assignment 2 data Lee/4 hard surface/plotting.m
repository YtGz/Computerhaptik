load k0_8__A0_2__d2__f242.txt;
[n,p,q,r] = size(k0_8__A0_2__d2__f242);
t = 1:n;
t = t*0.05*0.01;
k0_8__A0_2__d2__f242(:,2) = k0_8__A0_2__d2__f242(:,2)*100;
k0_8__A0_2__d2__f242(:,3) = k0_8__A0_2__d2__f242(:,3)*100;
k0_8__A0_2__d2__f242(:,4) = k0_8__A0_2__d2__f242(:,4)*100;
figure
plot(t,k0_8__A0_2__d2__f242),
xlabel('Time [s]'), ylabel('Force [J/cm]')
title('4 Hard Surface (k = 0.8, A = 0.2, d = 2, f = 242Hz)'),
legend('Position [mm]', 'Spring', 'Decaying Sinusoid', 'Combined Force [J/cm]');
yyaxis right
plot(t,k0_8__A0_2__d2__f242(:,1)),
ylabel('Position [mm]')
saveas(gcf, '4_hard_surface_k0_8__A0_2__d2__f242', 'svg');

load k0_8__A0_4__d0_5__f24.txt;
[n,p,q,r] = size(k0_8__A0_4__d0_5__f24);
t = 1:n;
t = t*0.05*0.01;
k0_8__A0_4__d0_5__f24(:,2) = k0_8__A0_4__d0_5__f24(:,2)*100;
k0_8__A0_4__d0_5__f24(:,3) = k0_8__A0_4__d0_5__f24(:,3)*100;
k0_8__A0_4__d0_5__f24(:,4) = k0_8__A0_4__d0_5__f24(:,4)*100;
figure
plot(t,k0_8__A0_4__d0_5__f24),
xlabel('Time [s]'), ylabel('Force [J/cm] // Position [mm]')
title('4 Hard Surface (k = 0.8, A = 0.4, d = 0.5, f = 24Hz)'),
legend('Spring', 'Decaying Sinusoid', 'Combined Force [J/cm]');
yyaxis right
plot(t,k0_8__A0_4__d0_5__f24(:,1)),
ylabel('Position [mm]')
saveas(gcf, '4_hard_surface_k0_8__A0_4__d0_5__f24', 'svg');

zoom on