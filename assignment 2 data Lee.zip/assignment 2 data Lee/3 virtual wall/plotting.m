load k3_0_v2.txt;
[n,p] = size(k3_0_v2);
t = 1:n;
t = t*0.05*0.01;
k3_0_v2(:,2) = k3_0_v2(:,2)*10;
plot(t,k3_0_v2),
xlabel('Time [s]'), ylabel('Force [J/dm] // Position [mm]')
title('3 Virtual Wall (k = 3)'),
legend('Position [mm]', 'Force [J/cm]');
saveas(gcf, '3_virtual_wall_k3_0_v2', 'svg');
