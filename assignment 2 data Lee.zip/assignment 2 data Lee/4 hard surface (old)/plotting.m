load k0_3__A2_4__d1__f181.txt;
[n,p,q,r] = size(k0_3__A2_4__d1__f181);
t = 1:n;
t = t*0.05*0.01;
k0_3__A2_4__d1__f181(:,2) = k0_3__A2_4__d1__f181(:,2)*100;
k0_3__A2_4__d1__f181(:,3) = k0_3__A2_4__d1__f181(:,3)*100;
k0_3__A2_4__d1__f181(:,4) = k0_3__A2_4__d1__f181(:,4)*100;
plot(t,k0_3__A2_4__d1__f181),
xlabel('Time [s]'), ylabel('Force [J/cm] // Position [mm]')
title('4 Hard Surface (k = 0.03, A = 0.2, d = 2, f = 24Hz)'),
legend('Position [mm]', 'Spring', 'Decaying Sinusoid', 'Combined Force [J/cm]');

yyaxis right
plot(t,k0_3__A2_4__d1__f181(:,1)),
ylabel('Position [mm]')