load Spring_k0_85.txt;
[n,p] = size(Spring_k0_85);
t = 1:n;
t = t*0.0005;
Spring_k0_85(:,2) = Spring_k0_85(:,2)*10;

figure
plot(t,Spring_k0_85(:,2)),
xlabel('Time [s]'), ylabel('Force [J/cm]')
title('1 Spring (k = 0.85)'),
legend('Force [J/cm]');
yyaxis right
plot(t,Spring_k0_85(:,1)),
ylabel('Position [mm]')