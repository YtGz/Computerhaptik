% p v f
load b0_18_v2.txt;
[n,p] = size(b0_18_v2);
t = 1:n;
t = t*0.0005;
b0_18_v2(:,3) = b0_18_v2(:,3)*10;

figure
plot(t,b0_18_v2(:,3)),
xlabel('Time [s]'), ylabel('Force [J/cm]')
title('2b Viscous Friction (b = 0.18)'),
legend('Force [J/cm]');
yyaxis right
plot(t,b0_18_v2(:,2)),
ylabel('Velocity [mm/s]')